I5: Individual Assignment #5 – GUI Implementation
Erica Yee
IS 4300
yee.er@husky.neu.edu
ericayee.com/hci/

Web interface available at:
ericayee.com/hci-i5

Code available at:
github.com/ericayee/hci-i5
